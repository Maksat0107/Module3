package modul3.payment;

public interface IPayment {
    PaymentResult processPayment(double amount);
}
