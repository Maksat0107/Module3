package modul3.notification;

public interface INotification {
    void sendNotification(String message);
}
