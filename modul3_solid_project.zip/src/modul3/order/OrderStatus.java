package modul3.order;

public enum OrderStatus {
    NEW, PRICED, PAID, SHIPPED, DELIVERED, CANCELLED
}
